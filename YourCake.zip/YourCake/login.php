<?php
session_start();

require_once('db_connection.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = trim($_POST['password']);

    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['userlogin'] = ['username' => 'admin'];
        $_SESSION['role'] = 'admin';
        echo 'admin';
        exit;
    }

    if (empty($username) || empty($password)) {
        echo 'Please fill in both fields.';
        exit;
    }

    $sql_customer = "SELECT * FROM customer WHERE Cust_username = ? LIMIT 1";
    $stmt_cust = $db->prepare($sql_customer);
    $stmt_cust->execute([$username]);

    if ($stmt_cust->rowCount() > 0) {
        $user = $stmt_cust->fetch(PDO::FETCH_ASSOC);

        if (password_verify($password, $user['Password'])) {
            $_SESSION['userlogin'] = $user;
            $_SESSION['role'] = 'customer';
            echo 'customer';
            exit;
        }
    }

    $sql_seller = "SELECT * FROM seller WHERE Seller_Username = ? LIMIT 1";
    $stmt_seller = $db->prepare($sql_seller);
    $stmt_seller->execute([$username]);

    if ($stmt_seller->rowCount() > 0) {
        $user = $stmt_seller->fetch(PDO::FETCH_ASSOC);

        if (password_verify($password, $user['Password'])) {
            if ($user['Status'] === "Approved") {
                $_SESSION['userlogin'] = $user;
                $_SESSION['role'] = 'seller';
                echo 'seller';
                exit;
            } elseif ($user['Status'] === "Pending") {
                echo 'Pending';
                exit;
            } elseif ($user['Status'] === "Rejected") {
                $_SESSION['userlogin'] = $user;
                $_SESSION['role'] = 'seller';
                echo 'Rejected';
                exit;
            } else {
                echo 'UnknownStatus';
                exit;
            }
        } else {
            echo 'WrongPassword';
            exit;
        }
    } else {
        echo 'NoUser';
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="/itcc1023/midterms/img/logo.png" />
    <title>Your Cake - Login</title> 
    <link rel="stylesheet" href="css/loginstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="logo-container">
            <div class="image">
                <img src="/itcc1023/midterms/img/logo.png" alt="Logo">
            </div>
        </div>

        <form method="post" class="form-container">
            <h1>Your Cake</h1>
            <p id="login-error" class="error"></p>

            <div class="input-container">
                <i class='bx bxs-user icon'></i>
                <input type="text" name="username" id="username" placeholder="Username">
            </div>
            
            <div class="input-container">
                <i class='bx bxs-lock-alt icon' ></i>
                <input type="password" name="password" id="password" placeholder="Password">
            </div>
            <a href="#" class="forgot-password"><u>Forgot password?</u></a>
            <button class="login-btn" name="login" id="login">LOGIN</button>
            
            <div class="links">
                Sign up as a <a href="signup_customer.php"><u>customer</u></a><br> or <br> Sign up as a <a href="signup_seller.php"><u>Seller</u></a>
            </div>
        </form>
    </div>

    <script>
    $(function(){
        $('#login').click(function(e){
            e.preventDefault();

            var username = $('#username').val();
            var password = $('#password').val();

            $.ajax({
                type: 'POST',
                url: 'login.php', 
                data:  {username: username, password: password},
                success: function(data){
                    data = $.trim(data);

                    if (data === "admin") {
                        window.location.href = "admin/Admin.php";
                    } else if (data === "customer") {
                        window.location.href = "signup_customer.php";
                    } else if (data === "seller") {
                        window.location.href = "signup_seller.php"; 
                    } else if (data === "Pending") {
                        $('#login-error').text("Your account is still pending approval.");
                    } else if (data === "Rejected") {
                        window.location.href = "reverify_seller.php";
                    } else if (data === "UnknownStatus") {
                        $('#login-error').text("Login failed due to unknown account status. Please contact support.");
                    } else if (data === "WrongPassword") {
                        $('#login-error').text("Incorrect password.");
                    } else if (data === "NoUser") {
                        $('#login-error').text("No account found with that username.");
                    } else {
                        $('#login-error').text("An unexpected error occurred.");
                    }
                }
            });
        });
    });
    </script>
</body>
</html>
