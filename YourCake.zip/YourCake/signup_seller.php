<?php
session_start();
if (!empty($_SESSION['name'])) {
    header('location:Admin.php');
    exit;
} else if (!empty($_SESSION['cusname'])) {
    header('location:HomePage.php');
    exit;
}

require_once('db_connection.php');

$usernameErr = $phoneErr = $emailErr = $passwordErr = '';
$usernameVal = $firstname = $lastname = $middlename = $nameext = $phonenumber = $email = $street = $barangay = '';

if (isset($_POST['create'])) {
    $username     = $_POST['Username'];
    $firstname    = $_POST['fname'];
    $lastname     = $_POST['lname'];
    $middlename   = $_POST['Mname'];
    $nameext      = $_POST['Ename'];
    $phonenumber  = $_POST['pnumber'];
    $email        = $_POST['eadrress']; 
    $street       = ucwords(strtolower($_POST['street']));
    $barangay     = $_POST['barangay'];
    $password     = $_POST['password'];
    $cpassword    = $_POST['cpassword'];
    $housenumber  = $_POST['housenumber'] ?? '';
    $landmark     = isset($_POST['landmark']) ? ucwords(strtolower($_POST['landmark'])) : '';
    $shopname     = $_POST['shopname'];
    $shoptype     = $_POST['shoptype'];
    $latitude     = $_POST['latitude'] ?? '';
    $longitude    = $_POST['longitude'] ?? '';
    $customize    = $_POST['customize'] ?? '';

    $hasError = false;


    $checkUserSeller = $db->prepare("SELECT * FROM seller WHERE Seller_Username = ?");
    $checkUserSeller->execute([$username]);

    $checkUserCustomer = $db->prepare("SELECT * FROM customer WHERE Cust_Username = ?");
    $checkUserCustomer->execute([$username]);

    if ($checkUserSeller->rowCount() > 0 || $checkUserCustomer->rowCount() > 0) {
        $usernameErr = "Username already exists.";
        $hasError = true;
    }


    $checkPhoneSeller = $db->prepare("SELECT * FROM seller WHERE PhoneNumber = ?");
    $checkPhoneSeller->execute([$phonenumber]);

    $checkPhoneCustomer = $db->prepare("SELECT * FROM customer WHERE PhoneNumber = ?");
    $checkPhoneCustomer->execute([$phonenumber]);

    if ($checkPhoneSeller->rowCount() > 0 || $checkPhoneCustomer->rowCount() > 0) {
        $phoneErr = "Phone number already registered.";
        $hasError = true;
    }


    $checkEmailSeller = $db->prepare("SELECT * FROM seller WHERE Email = ?");
    $checkEmailSeller->execute([$email]);

    $checkEmailCustomer = $db->prepare("SELECT * FROM customer WHERE Email = ?");
    $checkEmailCustomer->execute([$email]);

    if ($checkEmailSeller->rowCount() > 0 || $checkEmailCustomer->rowCount() > 0) {
        $emailErr = "Email already registered.";
        $hasError = true;
    }


    if ($password !== $cpassword) {
        $passwordErr = "Passwords do not match.";
        $hasError = true;
    }

    $idPath = $picPath = $logoPath = $certPath = '';
    $uploadDir = 'uploads/';

    if (!$hasError) {
        function cleanFileName($filename) {
            return preg_replace("/[^a-zA-Z0-9\.\-_]/", "", $filename);
        }

        if (!empty($_FILES['idUpload']['name'])) {
            $idName = $username . "_" . cleanFileName(basename($_FILES['idUpload']['name']));
            $idPath = $idName;
            move_uploaded_file($_FILES['idUpload']['tmp_name'], $uploadDir . $idName);
        }

        if (!empty($_FILES['picUpload']['name'])) {
            $picName = $username . "_" . cleanFileName(basename($_FILES['picUpload']['name']));
            $picPath = $picName;
            move_uploaded_file($_FILES['picUpload']['tmp_name'], $uploadDir . $picName);
        }

        if (!empty($_FILES['logoUpload']['name'])) {
            $logoName = $username . "_" . cleanFileName(basename($_FILES['logoUpload']['name']));
            $logoPath = $logoName;
            move_uploaded_file($_FILES['logoUpload']['tmp_name'], $uploadDir . $logoName);
        }

        if (!empty($_FILES['certUpload']['name'])) {
            $certName = $username . "_" . cleanFileName(basename($_FILES['certUpload']['name']));
            $certPath = $certName;
            move_uploaded_file($_FILES['certUpload']['tmp_name'], $uploadDir . $certName);
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO seller (
            Seller_Username, FirstName, MiddleName, LastName, NameExt, PhoneNumber, Email, Street, HouseNo, Barangay, latitude, longitude, Password, ShopName, ShopType, Landmark, ValidId, SellerPicture, SellerLogo, Requirement, Status, Customization
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

        $stmt = $db->prepare($sql);
        $result = $stmt->execute([
            $username, $firstname, $middlename, $lastname, $nameext, $phonenumber, $email, $street, $housenumber, $barangay, $latitude, $longitude,
            $hashedPassword, $shopname, $shoptype, $landmark, $idPath, $picPath, $logoPath, $certPath, 'Pending', $customize
        ]);

        if ($result) {
            echo '<script>
                alert("Registration successful!");
                window.location.href = "login.php";
            </script>';
        } else {
            echo '<script>
                alert("Error occurred while saving data.");
            </script>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/signupstyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="/itcc1023/midterms/img/logo.png" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Seller Sign-Up</title>
    <style>
        #map {
            height: 200px;
            width: 81%;
            margin-top: 23px;
        }
        #locationResult {
            padding: 10px;
            background-color: #f0f8ff;
            border: 1px solid #007bff;
            margin-top: 10px;
            display: none;
        }
    </style>
</head>
<body>

<form class="form sellForm" method="POST" enctype="multipart/form-data">
    <a href="login.php" class="back"><&nbsp Back to Log In Page</a>    

    <div class="first">
        <h2>Full Name</h2>
        <input type="text" name="fname" class="data" placeholder="First Name" required value="<?= htmlspecialchars($firstname ?? '') ?>">
        <input type="text" name="lname" class="data" placeholder="Last Name" required value="<?= htmlspecialchars($lastname ?? '') ?>">
        <input type="text" name="Mname" class="data" placeholder="Middle Name"value="<?= htmlspecialchars($middlename ?? '') ?>">
        <input type="text" name="Ename" class="data" placeholder="Name Ext."value="<?= htmlspecialchars($nameext ?? '') ?>">
    </div>
    <div class="first">
            <br>
                <h2>Username</h2>
                <input type="text" name="Username" id="idUsername" class="data" placeholder="Username"required value="<?= htmlspecialchars($username ?? '') ?>">
                <p class="error"><?= $usernameErr ?></p>
            </div>
    <div class="first">
        <br>
        <h2>Contact Information</h2>
        <input type="tel" name="pnumber" class="data" placeholder="Phone Number" required pattern="\d{11}" maxlength="11" oninput="this.value = this.value.replace(/[^0-9]/g, '')" title="Phone number must be exactly 11 digits" value="<?= htmlspecialchars($phonenumber ?? '') ?>">
        <p class="error"><?= $phoneErr ?></p>
        <input type="email" name="eadrress" class="data" placeholder="Email Address" required value="<?= htmlspecialchars($email ?? '') ?>">
        <p class="error"><?= $emailErr ?></p>
    </div>

    <div class="first">
    <br>
        <h2>Complete Address</h2>
        <input type="text" name="street" class="data" placeholder="Street" required value="<?= htmlspecialchars($street ?? '') ?>">
        <input type="text" name="housenumber" class="data" placeholder="House Number" value="<?= htmlspecialchars($housenumber ?? '') ?>">
        <select name="barangay" class="data">
                <option value="Bagong Silang" <?= ($barangay ?? '') == 'Bagong Silang' ? 'selected' : '' ?>>Bagong Silang</option>
                <option value="Bagumbayan" <?= ($barangay ?? '') == 'Bagumbayan' ? 'selected' : '' ?>>Bagumbayan</option>
                <option value="Cabog Cabog" <?= ($barangay ?? '') == 'Cabog Cabog' ? 'selected' : '' ?>>Cabog Cabog</option>
                <option value="Camacho" <?= ($barangay ?? '') == 'Camacho' ? 'selected' : '' ?>>Camacho</option>
                <option value="Cataning" <?= ($barangay ?? '') == 'Cataning' ? 'selected' : '' ?>>Cataning</option>
                <option value="Central" <?= ($barangay ?? '') == 'Central' ? 'selected' : '' ?>>Central</option>
                <option value="Cupang North" <?= ($barangay ?? '') == 'Cupang North' ? 'selected' : '' ?>>Cupang North</option>
                <option value="Cupang Proper" <?= ($barangay ?? '') == 'Cupang Proper' ? 'selected' : '' ?>>Cupang Proper</option>
                <option value="Cupang West" <?= ($barangay ?? '') == 'Cupang West' ? 'selected' : '' ?>>Cupang West</option>
                <option value="Dangcol" <?= ($barangay ?? '') == 'Dangcol' ? 'selected' : '' ?>>Dangcol</option>
                <option value="Doña Francisca" <?= ($barangay ?? '') == 'Doña Francisca' ? 'selected' : '' ?>>Doña Francisca</option>
                <option value="Ibayo" <?= ($barangay ?? '') == 'Ibayo' ? 'selected' : '' ?>>Ibayo</option>
                <option value="Lote" <?= ($barangay ?? '') == 'Lote' ? 'selected' : '' ?>>Lote</option>
                <option value="Malabia" <?= ($barangay ?? '') == 'Malabia' ? 'selected' : '' ?>>Malabia</option>
                <option value="Munting Batangas" <?= ($barangay ?? '') == 'Munting Batangas' ? 'selected' : '' ?>>Munting Batangas</option>
                <option value="Poblacion" <?= ($barangay ?? '') == 'Poblacion' ? 'selected' : '' ?>>Poblacion</option>
                <option value="Pto. Rivas Ibaba" <?= ($barangay ?? '') == 'Pto. Rivas Ibaba' ? 'selected' : '' ?>>Pto. Rivas Ibaba</option>
                <option value="Pto. Rivas Itaas" <?= ($barangay ?? '') == 'Pto. Rivas Itaas' ? 'selected' : '' ?>>Pto. Rivas Itaas</option>
                <option value="San Jose" <?= ($barangay ?? '') == 'San Jose' ? 'selected' : '' ?>>San Jose</option>
                <option value="Sibacan" <?= ($barangay ?? '') == 'Sibacan' ? 'selected' : '' ?>>Sibacan</option>
                <option value="Talisay" <?= ($barangay ?? '') == 'Talisay' ? 'selected' : '' ?>>Talisay</option>
                <option value="Tanato" <?= ($barangay ?? '') == 'Tanato' ? 'selected' : '' ?>>Tanato</option>
                <option value="Tenejero" <?= ($barangay ?? '') == 'Tenejero' ? 'selected' : '' ?>>Tenejero</option>
                <option value="Tortugas" <?= ($barangay ?? '') == 'Tortugas' ? 'selected' : '' ?>>Tortugas</option>
        </select>
        <input type="text" name="landmark" class="data" placeholder="Landmark" value="<?= htmlspecialchars($landmark ?? '') ?>">
    </div>
    <div class="first">
    <div id="map"></div>
    </div>
    

    <div class="first">
        <br><br>
        <h2>Security</h2>
        <input type="password" name="password" class="data" placeholder="Password"pattern="^(?=.*[A-Z])(?=.*[\W_]).{8,20}$"
    title="Password must be 8-20 characters, include at least one uppercase letter and one special character."
    required>
        
        <input type="password" name="cpassword" class="data" placeholder="Confirm Password"> 
        <p class="error"><?= $passwordErr ?></p>
    </div>

    <div class="first">
        <br><br>
            <h2>Shop Details</h2> 
            <input type="text" name="shopname" class="data" placeholder="Shop Name" required value="<?= htmlspecialchars($shopname ?? '') ?>">>
            <select name="shoptype" class="data" required>
                <option value="">Select Shop Type</option>
                <option value="Bakery" <?= (isset($shoptype) && $shoptype == 'Bakery') ? 'selected' : '' ?>>Bakery</option>
                <option value="Custom Cakes" <?= (isset($shoptype) && $shoptype == 'Custom Cakes') ? 'selected' : '' ?>>Custom Cakes</option>
            </select>
            <br>
            <p>Do you offer Customization: </p>
             <input type="radio" id="Yes" name="customize" value="Yes" <?= (isset($customize) && $customize === 'Yes') ? 'checked' : '' ?>>
             <label for="Yes">Yes</label><br>
             <input type="radio" id="No" name="customize" value="No" <?= (isset($customize) && $customize === 'No') ? 'checked' : '' ?>>
             <label for="No ">No</label><br>
    </div>

    <div class="first">
        <br><br>
        <h2>Seller's Valid Identification ID</h2>
        <img src="" alt="" class="input-image" id="idPreview" onclick="document.getElementById('idUpload').click()" style="cursor:pointer;">
        <input type="file" name="idUpload" id="idUpload" accept="image/*" style="display:none;" onchange="previewImage(event, 'idPreview')" required>
    </div>

    <div class="first">
        <br><br>
        <h2>Seller's Picture</h2>
        <img src="" alt="" class="input-image" id="picPreview" onclick="document.getElementById('picUpload').click()" style="cursor:pointer;">
        <input type="file" name="picUpload" id="picUpload" accept="image/*" style="display:none;" onchange="previewImage(event, 'picPreview')" required>
    </div>

    <div class="first">
        <br><br>
        <h2>Shop's Logo</h2>
        <img src="" alt="" class="input-image" id="logoPreview" onclick="document.getElementById('logoUpload').click()" style="cursor:pointer;">
        <input type="file" name="logoUpload" id="logoUpload" accept="image/*" style="display:none;" onchange="previewImage(event, 'logoPreview')" required>
    </div>
    <div class="first">
        <br><br>
        <h2>BIR/Brgy. Cetificate</h2>
        <img src="" alt="" class="input-image" id="certPreview" onclick="document.getElementById('certUpload').click()" style="cursor:pointer;">
        <input type="file" name="certUpload" id="certUpload" accept="image/*" style="display:none;" onchange="previewImage(event, 'certPreview')" required>
    </div>
    <input type="hidden" name="latitude" id="latitude">
    <input type="hidden" name="longitude" id="longitude">

    <div class="first">
        <button type="submit" name="create" class="submit">Sign-Up</button>
    </div>
</form>

<div class="logo sellerL">
    <img src="/itcc1023/midterms/img/logo.png" alt="">
    <h3>Seller</h3>
    <h2>Sign Up</h2>
</div>

<script>
function previewImage(event, previewId) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById(previewId).src = e.target.result;
        }
        reader.readAsDataURL(file);
    }
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDsyCZpAJ4FEq6CxKn97q8oNdhyUsUxvFc&callback=initMap" async defer></script>
        
        <script>
        var map, marker, geocoder;
        
        function initMap() {
            var defaultLocation = { lat: 14.678886402185922, lng: 120.54064149611898 }; 
            
        
            map = new google.maps.Map(document.getElementById('map'), {
                center: defaultLocation,
                zoom: 13
            });
        
            geocoder = new google.maps.Geocoder();
        
            marker = new google.maps.Marker({
                position: defaultLocation,
                map: map,
                draggable: true
            });
        
            updateLocation(marker.getPosition());
        
            marker.addListener('dragend', function() {
                updateLocation(marker.getPosition());
            });
        
            map.addListener('click', function(event) {
                marker.setPosition(event.latLng);
                updateLocation(event.latLng);
            });
        
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var userLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    map.setCenter(userLocation);
                    marker.setPosition(userLocation);
                    updateLocation(marker.getPosition());
                }, function() {
                    alert('Error: Location service failed or blocked.');
                });
            } else {
                alert('Error: Your browser does not support geolocation.');
            }
        }
        
        function updateLocation(latLng) {
            document.getElementById('latitude').value = latLng.lat();
            document.getElementById('longitude').value = latLng.lng();
        
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('signupForm').addEventListener('submit', function(event) {
        
                var latitude = document.getElementById('latitude').value;
                var longitude = document.getElementById('longitude').value;
            });
        });
        </script>
    
</body>
</html>
