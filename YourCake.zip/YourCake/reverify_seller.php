<?php
session_start();
require_once('db_connection.php');
if (!isset($_SESSION['userlogin']) || !isset($_SESSION['userlogin']['Seller_Username'])) {
    header("Location: login.php");
    exit();
}
$seller = $_SESSION['userlogin'];
$username = $seller['Seller_Username'];


$error = '';
$success = '';

if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}

if (isset($_POST['submit'])) {
    $password = $_POST['password'];

    $stmt = $db->prepare("SELECT * FROM seller WHERE Seller_Username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, $user['Password'])) {
        $error = "Incorrect password.";
    } 
    
    elseif (empty($_FILES["valid_id"]["name"]) || empty($_FILES["seller_picture"]["name"]) || empty($_FILES["bir_cert"]["name"])) {
        $error = "Please upload all required images before submitting.";
    } 
    else {
        
        $targetDir = "uploads/";
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];

        $validIDTmp = $_FILES["valid_id"]["tmp_name"];
        $pictureTmp = $_FILES["seller_picture"]["tmp_name"];
        $requirementTmp = $_FILES["bir_cert"]["tmp_name"];

        $validIDType = mime_content_type($validIDTmp);
        $pictureType = mime_content_type($pictureTmp);
        $requirementType = mime_content_type($requirementTmp);

        if (
            in_array($validIDType, $allowedTypes) &&
            in_array($pictureType, $allowedTypes) &&
            in_array($requirementType, $allowedTypes)
        ) {
            function cleanFileName($filename) {
                return preg_replace("/[^a-zA-Z0-9\.\-_]/", "", $filename);
            }
            
            $validIDName = $username ."_" . cleanFileName(basename($_FILES["valid_id"]["name"]));
            $pictureName = $username . "_" .cleanFileName(basename($_FILES["seller_picture"]["name"]));
            $requirementName = $username . "_" .cleanFileName(basename($_FILES["bir_cert"]["name"]));

            $validIDPath = $validIDName;
            $picturePath = $pictureName;
            $requirementPath = $requirementName;

            if (
                move_uploaded_file($validIDTmp, $targetDir . $validIDName) &&
                move_uploaded_file($pictureTmp, $targetDir . $pictureName) &&
                move_uploaded_file($requirementTmp, $targetDir . $requirementName)
            ) {
                $update = $db->prepare("UPDATE seller SET ValidID = ?, SellerPicture = ?, Requirement = ?, Status = 'Pending' WHERE Seller_Username = ?");
                $update->execute([$validIDPath, $picturePath, $requirementPath, $username]);
                $_SESSION['success'] = "Reverification submitted successfully! Please log in again.";
                session_unset();
                session_destroy();
                header("Location: login.php");
                exit();
                
            } else {
                $error = "File upload failed. Please try again.";
            }
        } else {
            $error = "Invalid file type. Only JPG and PNG images are allowed.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Seller Reverification</title>
    <link rel="stylesheet" href="css/signupstyle.css">
</head>
<body>

    <form action="" class="form sellForm" method="POST" enctype="multipart/form-data">
        <a href="logout.php" class="back"><&nbsp Back to Log In Page</a>

        <div class="first">
            <h2>Username</h2>
            <input type="text" name="username" class="data" value="<?= htmlspecialchars($username) ?>" readonly>
        </div>

        <div class="first">
            <br>
            <h2>Seller's Valid Identification ID</h2>
            <img src="" alt="" class="input-image" id="idPreview" onclick="document.getElementById('idUpload').click()" style="cursor:pointer;">
            <input type="file" name="valid_id" id="idUpload" accept="image/*" style="display:none;" onchange="previewImage(event, 'idPreview')">
        </div>

        <div class="first">
            <br>
            <h2>Seller Picture</h2>
            <img src="" alt="" class="input-image" id="picPreview" onclick="document.getElementById('picUpload').click()" style="cursor:pointer;">
            <input type="file" name="seller_picture" id="picUpload" accept="image/*" style="display:none;" onchange="previewImage(event, 'picPreview')">
        </div>

        <div class="first">
            <br>
            <h2>BIR/Barangay Certificate</h2>
            <img src="" alt="" class="input-image" id="certPreview" onclick="document.getElementById('certUpload').click()" style="cursor:pointer;">
            <input type="file" name="bir_cert" id="certUpload" accept="image/*" style="display:none;" onchange="previewImage(event, 'certPreview')">
        </div>

        <div class="first">
            <br>
            <h2>Confirm Password</h2>
            <input type="password" name="password" class="data" placeholder="Enter Password" required>
        </div>

        <input type="submit" name="submit" value="Submit Reverification" class="submit">

        <!--   error/ -->
        <div>
            <?php if ($error): ?>
                <p class="error" style="color:red;"><?= $error ?></p>
            <?php elseif ($success): ?>
                <p class="success" style="color:green;"><?= $success ?></p>
            <?php endif; ?>
        </div>
    </form>

    <div class="logo">
        <img src="/itcc1023/midterms/img/logo.png" alt="">
        <h3>Seller</h3>
        <br>
        <h2>Re-Verification</h2>
    </div>

<script>
function previewImage(event, previewId) {
    const reader = new FileReader();
    reader.onload = function(){
        const output = document.getElementById(previewId);
        output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
}
//validation
document.querySelector('.sellForm').addEventListener('submit', function(e) {
    let validID = document.getElementById('idUpload').files.length;
    let picture = document.getElementById('picUpload').files.length;
    let cert = document.getElementById('certUpload').files.length;

    let oldWarning = document.getElementById('warnMsg');
    if (oldWarning) oldWarning.remove();

    if (validID === 0 || picture === 0 || cert === 0) {
        e.preventDefault();

        let p = document.createElement('p');
        p.textContent = "Please upload all required images before submitting.";
        p.id = "warnMsg";
        p.style.color = "red";
        p.style.marginTop = "10px";

        document.querySelector('.sellForm').appendChild(p);
    }
});


window.onload = function() {
    document.getElementById('idUpload').value = "";
    document.getElementById('picUpload').value = "";
    document.getElementById('certUpload').value = "";

    document.getElementById('idPreview').src = "";
    document.getElementById('picPreview').src = "";
    document.getElementById('certPreview').src = "";
};
</script>
</body>
</html>
