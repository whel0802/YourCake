<?php
$db_user = "root";
$db_pass = "";
$db_name = "yourcake";


try {
    $db = new PDO('mysql:host=localhost;dbname=' . $db_name . ';charset=utf8', $db_user, $db_pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}

$conn = new mysqli('localhost', $db_user, $db_pass, $db_name);
    
if ($conn->connect_error) {
    die("MySQLi Connection failed: " . $conn->connect_error);
}
?>  

