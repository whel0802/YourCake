<?php
session_start();    
if (empty($_SESSION['userlogin'])) {
    header('Location: ../login.php');
    exit;
}
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}


$user = isset($_SESSION['userlogin']['username']) ? $_SESSION['userlogin']['username'] : '';

include("../db_connection.php");

if (isset($_SESSION['success'])) {
    echo "<script>alert('{$_SESSION['success']}');</script>";
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    echo "<script>alert('{$_SESSION['error']}');</script>";
    unset($_SESSION['error']);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="/YourCake/pic/logo.png" />

    <!---  CSS -->
    <link rel="stylesheet" href="../css/SellerNavbar.css">
    <link rel="stylesheet" href="../css/SellerProduct.css">

    <!--- Boxicons CSS -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 

    <title>YourCake</title>
</head>
<body>
    <nav class="sidebar close">
        <header>
            <i class='bx bx-menu toggle icon'></i>
            <div class="image-text">
                <span class="image">
                    <img src="/YourCake/pic/logo.png" alt="logo">
                </span>

                <div class="text header-text">
                    <span class="name"> YourCake
                    <span class="user"><?php echo $user; ?></p>
                </div>
            </div>
            
        </header>

        <div class="menu-bar">
            <div class="menu">
            <ul class="menu-links">
                    
                    <li class="nav-link">
                        <a href="Admin_SellerList.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Home</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="Admin_SellerList.php">
                            <i class='bx bx-customize icon'></i>
                            <span class="text nav-text">Customization</span>
                        </a>
                    </li>
                    <li class="nav-link">
                         <a href="Admin_Users.php">
                            <i class='bx bx-list-ul icon' ></i>
                            <span class="text nav-text">Product List</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="Admin_Dropdown.php">
                            <i class='bx bx-calendar icon' ></i>
                            <span class="text nav-text">Schedule</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-bar-chart-square icon' ></i>
                            <span class="text nav-text">Sales</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-cabinet icon' ></i>
                            <span class="text nav-text">Inventory</span>
                        </a>
                    </li>
                    
                </ul>
            </div>

            <div class="bottom-content">
                <li class="nav-link">
                    <a href="../logout.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
            </div>
        </div>
    </nav>


    <section class="Content">

        <div class="container">
            <div class="ProductTable">
                <div class="prodHeader">
                    <i class='bx bx-list-ul icon' ></i>
                    <span class="prodSpan">Seller List</span>
                </div>

                <div class="prodControls">
                    <p>Filtered by:</p>
                    <select name="filter" id="filter-dropdown">
                        <option value="all">All</option>
                        <option value="Approved">Approved</option>
                        <option value="Pending">Pending</option>
                        <option value="Rejected">Rejected</option>
                    </select>
                </div>
                <table class="ProdTable" id="ProdTable">
                    <thead>
                        <tr class="tableHeader">
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Phone Number</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Shop Name</th>
                            <th>Shop Type</th>
                            <th>Landmark</th>
                            <th>Valid ID</th>
                            <th>Seller's Picture</th>
                            <th>Seller's Logo</th>
                            <th>Requirement</th>
                            <th>Status</th>
                            <th>Customization</th>
                            <th>Action</th>
                        </tr>
                    </thead>
<tbody>
                    </tbody>
                </table>
                
            </div>
            
            </div>

    </section>

    <script src="../navbar.js"></script>
    <script src="/YourCake/js/product.js"></script>

    <!-- Image Preview Modal -->
    <div id="imagePreviewModal" class="modal">
        <span class="close">&times;</span>
        <img class="modal-content" id="previewImage">
        <div id="caption"></div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get modal elements
            const modal = document.getElementById('imagePreviewModal');
            const modalImg = document.getElementById('previewImage');
            const captionText = document.getElementById('caption');
            const closeBtn = modal.querySelector('.close');

            // Function to open modal with clicked image
            function openImagePreview(event) {
                if (event.target.tagName.toLowerCase() === 'img') {
                    modal.style.display = "block";
                    modalImg.src = event.target.src;
                    captionText.innerHTML = event.target.alt || "";
                }
            }

            // Use event delegation: attach click event to the table
            const table = document.getElementById('ProdTable');
            if (table) {
                table.style.cursor = 'pointer';
                table.addEventListener('click', openImagePreview);
            }

            // Close modal on close button click
            closeBtn.onclick = function() {
                modal.style.display = "none";
            }

            // Close modal on clicking outside the image
            modal.onclick = function(event) {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            }

            // Filter table rows based on status
            const filterDropdown = document.getElementById('filter-dropdown');
            filterDropdown.addEventListener('change', function() {
                const filterValue = this.value.toLowerCase();
                const rows = document.querySelectorAll('#ProdTable tbody tr');
                rows.forEach(row => {
                    const statusCell = row.cells[12]; // Status is the 13th column (0-based index 12)
                    if (!statusCell) return;
                    const statusText = statusCell.textContent.toLowerCase();
                    if (filterValue === 'all' || statusText === filterValue) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
    function applyFilter() {
        const filterValue = $('#filter-dropdown').val().toLowerCase();
        $('#ProdTable tbody tr').each(function() {
            const statusText = $(this).find('td').eq(11).text().toLowerCase();
            if (filterValue === 'all' || statusText === filterValue) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }

    function fetchSellers() {
        $.ajax({
            url: '../functions/get_sellers.php',
            type: 'GET',
            success: function(data) {
                $('#ProdTable tbody').html(data);
                applyFilter();
            },
            error: function() {
                console.error('Failed to fetch sellers');
            }
        });
    }

    $(document).on('click', '.delete-button', function(){
      var id = $(this).data('id');

      Swal.fire({
          title: 'Choose an action',
          text: "Approve or Reject this seller?",
          icon: 'question',
          showDenyButton: true,
          showCancelButton: true,
          confirmButtonText: 'Approve',
          denyButtonText: 'Reject',
          cancelButtonText: 'Cancel',
      }).then((result) => {
          if (result.isConfirmed) {
              $.ajax({
                  url: '../functions/update_seller_status.php',
                  type: 'POST',
                  data: { SellerUsername: id, Status: 'Approved' },
                  success: function(response){
                      if(response.trim() === "success"){
                          Swal.fire(
                              'Approved!',
                              'Seller has been approved.',
                              'success'
                          );
                          fetchSellers();
                      } else {
                          Swal.fire(
                              'Error!',
                              'Failed to approve seller.',
                              'error'
                          );
                      }
                  }
              });
          } else if (result.isDenied) {
              // Reject action
              $.ajax({
                  url: '../functions/update_seller_status.php',
                  type: 'POST',
                  data: { SellerUsername: id, Status: 'Rejected' },
                  success: function(response){
                      if(response.trim() === "success"){
                          Swal.fire(
                              'Rejected!',
                              'Seller has been rejected.',
                              'success'
                          );
                          fetchSellers();
                      } else {
                          Swal.fire(
                              'Error!',
                              'Failed to reject seller.',
                              'error'
                          );
                      }
                  }
              });
          } else {
            // Cancel action
            $("#add-update").text("Add");
            $("#productForm")[0].reset();
            $("#preview").attr("src", "default.jpg");
            document.getElementById('prodName').readOnly = false;
          }
      });
    });

    // Apply filter on dropdown change
    $('#filter-dropdown').on('change', function() {
        applyFilter();
    });

    // Initial fetch of sellers on page load
    $(document).ready(function() {
        fetchSellers();
    });
    </script>
</body>
</html>
    