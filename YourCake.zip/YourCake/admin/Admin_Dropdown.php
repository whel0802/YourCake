    <?php
session_start();    
if (empty($_SESSION['userlogin'])) {
    header('Location: ../login.php');
    exit;
}
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$user = isset($_SESSION['userlogin']['username']) ? $_SESSION['userlogin']['username'] : '';

include("../db_connection.php");

if (isset($_SESSION['success'])) {
    echo "<script>alert('{$_SESSION['success']}');</script>";
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    echo "<script>alert('{$_SESSION['error']}');</script>";
    unset($_SESSION['error']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="/YourCake/pic/logo.png" />

    <!--- CSS -->
    <link rel="stylesheet" href="../css/SellerNavbar.css">
    <link rel="stylesheet" href="../css/SellerProduct.css">

    <!--- Boxicons CSS -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>YourCake</title>
</head>
<body>
    <nav class="sidebar close">
        <header>
            <i class='bx bx-menu toggle icon'></i>
            <div class="image-text">
                <span class="image">
                    <img src="/YourCake/pic/logo.png" alt="logo">
                </span>

                <div class="text header-text">
                    <span class="name"> YourCake
                    <span class="user"><?php echo $user; ?></p>
                </div>
            </div>
            
        </header>

        <div class="menu-bar">
            <div class="menu">
            <ul class="menu-links">
                    
                    <li class="nav-link">
                        <a href="Admin_SellerList.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Home</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="Admin_SellerList.php">
                            <i class='bx bx-customize icon'></i>
                            <span class="text nav-text">Customization</span>
                        </a>
                    </li>
                    <li class="nav-link">
                         <a href="Admin_Users.php">
                            <i class='bx bx-list-ul icon' ></i>
                            <span class="text nav-text">Product List</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="Admin_Dropdown.php">
                            <i class='bx bx-calendar icon' ></i>
                            <span class="text nav-text">Schedule</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-bar-chart-square icon' ></i>
                            <span class="text nav-text">Sales</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-cabinet icon' ></i>
                            <span class="text nav-text">Inventory</span>
                        </a>
                    </li>
                    
                </ul>
            </div>

            <div class="bottom-content">
                <li class="nav-link">
                    <a href="../logout.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
            </div>
        </div>
    </nav>


    <section class="Content">

        <div class="container">
            <div class="ProductTable">
                <div class="prodHeader">
                    <i class='bx bx-list-ul icon' ></i>
                    <span class="prodSpan">Category</span>
                </div>
                <div class="prodControls2">
                    
                    <form id="addCategoryForm">
                        <input type="text" id="newPurposeInput" name="newPurpose" placeholder="New Purpose Name" style="display:none; margin-bottom: 10px;" >
                        <input type="text" id="categoryName" name="categoryName" placeholder="Option Name" required>
                        <select name="purpose" id="purpose-dropdown" required>
                            <option value="all">Select Purpose</option>
                            <?php
                            $purposes = [];
                            $sql = "SELECT DISTINCT Purpose FROM options WHERE Status = 'Active'";
                            $result = $conn->query($sql);
                            if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $purpose = htmlspecialchars($row['Purpose']);
                                    echo "<option value=\"{$purpose}\">{$purpose}</option>";
                                }
                            }
                            ?>
                            <option value="New">New</option>
                        </select>
                        <button type="submit" id="btnCateg">Add Category</button>
                    </form>
                    <div class="filterContainer">
                        <p>Filtered by:</p>
                        <select name="filter" id="filter-dropdown">
                        <option value="all">All</option>
                        <?php
                        $purposes = [];
                        $sql = "SELECT DISTINCT Purpose FROM options WHERE Status = 'Active'";
                        $result = $conn->query($sql);
                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $purpose = htmlspecialchars($row['Purpose']);
                                echo "<option value=\"{$purpose}\">{$purpose}</option>";
                            }
                        }
                        ?>
                        
                        </select>
                    </div>
                
                  <table class="ProdTableCategory" id="ProdTableCategory">
                    <thead>
                        <tr class="tableHeader">
                            <th>ID</th>
                            <th>Purpose</th>
                            <th>Option</th>
                            <th>Action</th>
                        </tr>
                    </thead>
<tbody> 
                    </tbody>
                </table>
                
            </div>
            </div>
        </div>

    <script>
    function applyFilter() {
        const filterValue = $('#filter-dropdown').val().toLowerCase();
        $('#ProdTableCategory tbody tr').each(function() {
            const statusText = $(this).find('td').eq(1).text().toLowerCase();
            if (filterValue === 'all' || statusText === filterValue) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }

    function fetchCategory() {
        $.ajax({
            url: '../functions/get_category.php',
            type: 'GET',
            success: function(data) {
                $('#ProdTableCategory tbody').html(data);
                applyFilter();
            },
            error: function() {
                console.error('Failed to fetch categories');
            }
        });
    }

    $(document).on('click', '.delete-button', function() {
      var id = $(this).data('id');

      Swal.fire({
          title: 'Are you sure?',
          text: "This action cannot be undone.",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Yes, delete it!',
          cancelButtonText: 'Cancel'
      }).then((result) => {
          if (result.isConfirmed) {
              $.ajax({
                  url: '../functions/delete_category.php',
                  type: 'POST',
                  data: { id: id },
                  success: function(response) {
                      if (response.trim() === "success") {
                          Swal.fire('Deleted!', 'Category has been deleted.', 'success');
                          fetchCategory();
                      } else {
                          Swal.fire('Error!', 'Failed to delete category.', 'error');
                      }
                  }
              });
          }
      });
    });

    // show o hide
    $('#purpose-dropdown').on('change', function() {
        if ($(this).val() === 'New') {
            $('#newPurposeInput').show();
            $('#categoryName').show();
        } else {
            $('#newPurposeInput').hide();
            $('#categoryName').show();
        }
    });


    $(document).ready(function() {
        fetchCategory();


        $('#addCategoryForm').on('submit', function(e) {
            e.preventDefault();
            const categoryName = $('#categoryName').val().trim();
            const newPurpose = $('#newPurposeInput').val().trim();
            const purpose = $('#purpose-dropdown').val();

            if (purpose === 'all') {
                Swal.fire('Please select Purpose');
                return;
            }

            if (purpose === 'New') {
                if (newPurpose === '') {
                    Swal.fire('Please enter New Purpose Name');
                    return;
                }
                if (categoryName === '') {
                    Swal.fire('Please enter Option Name');
                    return;
                }
            } else {
                if (categoryName === '') {
                    Swal.fire('Please enter Option Name');
                    return;
                }
            }

            let dataToSend = {};
            if (purpose === 'New') {
                dataToSend = { Options: categoryName, Purpose: newPurpose };
            } else {
                dataToSend = { Options: categoryName, Purpose: purpose };
            }

            $.ajax({
                url: '../functions/add_option.php',
                type: 'POST',
                data: dataToSend,
                success: function(response) {
                    console.log('Add option response:', response);
                    if (response.trim() === 'success') {
                        Swal.fire('Added!', 'Category has been added.', 'success');
                        $('#categoryName').val('');
                        $('#newPurposeInput').val('');
                        $('#purpose-dropdown').val('all');
                        $('#newPurposeInput').hide();
                        fetchCategory();
                       // update 
                        $.ajax({
                            url: '../functions/get_purposes.php',
                            type: 'GET',
                            success: function(purposesData) {
                                // Update both filter dropdown
                                $('#filter-dropdown').html(purposesData);
                                $('#purpose-dropdown').html(purposesData + '<option value="New">New</option>');
                                applyFilter();
                                
                                if (purposesData.indexOf('value="' + newPurpose + '"') !== -1) {
                                    $('#purpose-dropdown').val(newPurpose);
                                } else {
                                    $('#purpose-dropdown').val('all');
                                }
                            },
                            error: function() {
                                console.error('Failed to update filter dropdown');
                            }
                        });
                    } else if (response.trim() === 'Duplicate entry' || response.trim() === 'Duplicate purpose') {
                        Swal.fire('Warning!', 'This entry already exists.', 'warning');
                    } else {
                        Swal.fire('Error!', 'Failed to add category.', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Add option AJAX error:', status, error);
                    Swal.fire('Error!', 'Failed to add category.', 'error');
                }
            });
        });
    });
    </script>

    </section>

    <script src="../navbar.js"></script>
    <script src="/YourCake/js/product.js"></script>
>
-
-    <script>

-            const filterDropdown = document.getElementById('filter-dropdown');
-            filterDropdown.addEventListener('change', function() {
-                const filterValue = this.value.toLowerCase();
-                const rows = document.querySelectorAll('#ProdTableCategory tbody tr');
-                rows.forEach(row => {
-                    const statusCell = row.cells[1]; 
-                    if (!statusCell) return;
-                    const statusText = statusCell.textContent.toLowerCase();
-                    if (filterValue === 'all' || statusText === filterValue) {
-                        row.style.display = '';
-                    } else {
-                        row.style.display = 'none';
-                    }
-                });
-            });

-    </script>
+    <script>
+        // Filter table rows based on status
+        const filterDropdown = document.getElementById('filter-dropdown');
+        filterDropdown.addEventListener('change', function() {
+            const filterValue = this.value.toLowerCase();
+            const rows = document.querySelectorAll('#ProdTableCategory tbody tr');
+            rows.forEach(row => {
+                const statusCell = row.cells[1];
+                if (!statusCell) return;
+                const statusText = statusCell.textContent.toLowerCase();
+                if (filterValue === 'all' || statusText === filterValue) {
+                    row.style.display = '';
+                } else {
+                    row.style.display = 'none';
+                }
+            });
+        });
+    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
    function applyFilter() {
        const filterValue = $('#filter-dropdown').val().toLowerCase();
        $('#ProdTableCategory tbody tr').each(function() {
            const statusText = $(this).find('td').eq(1).text().toLowerCase();
            if (filterValue === 'all' || statusText === filterValue) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }

    function fetchSellers() {
        $.ajax({
            url: '../functions/get_category.php',
            type: 'GET',
            success: function(data) {
                $('#ProdTableCategory tbody').html(data);
                applyFilter();
            },
            error: function() {
                console.error('Failed to fetch sellers');
            }
        });
    }

    $(document).on('click', '.delete-button', function(){
      var id = $(this).data('id');

      Swal.fire({
          title: 'Choose an action',
          text: "Approve or Reject this seller?",
          icon: 'question',
          showDenyButton: true,
          showCancelButton: true,
          confirmButtonText: 'Approve',
          denyButtonText: 'Reject',
          cancelButtonText: 'Cancel',
      }).then((result) => {
          if (result.isConfirmed) {
              $.ajax({
                  url: '../functions/update_seller_status.php',
                  type: 'POST',
                  data: { SellerUsername: id, Status: 'Approved' },
                  success: function(response){
                      if(response.trim() === "success"){
                          Swal.fire(
                              'Approved!',
                              'Seller has been approved.',
                              'success'
                          );
                          fetchSellers();
                      } else {
                          Swal.fire(
                              'Error!',
                              'Failed to approve seller.',
                              'error'
                          );
                      }
                  }
              });
          } else if (result.isDenied) {
              // Reject action
              $.ajax({
                  url: '../functions/update_seller_status.php',
                  type: 'POST',
                  data: { SellerUsername: id, Status: 'Rejected' },
                  success: function(response){
                      if(response.trim() === "success"){
                          Swal.fire(
                              'Rejected!',
                              'Seller has been rejected.',
                              'success'
                          );
                          fetchSellers();
                      } else {
                          Swal.fire(
                              'Error!',
                              'Failed to reject seller.',
                              'error'
                          );
                      }
                  }
              });
          } else {
            // Cancel action
            $("#add-update").text("Add");
            $("#productForm")[0].reset();
            $("#preview").attr("src", "default.jpg");
            document.getElementById('prodName').readOnly = false;
          }
      });
    });

    // New handler for inactive-button
    $(document).on('click', '.inactive-button', function(){
        var id = $(this).data('id');

        Swal.fire({
            title: 'Are you sure?',
            text: "This will set the status to Inactive.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, set inactive',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../functions/update_option_status.php',
                    type: 'POST',
                    data: { OptionID: id },
                    success: function(response) {
                        if(response.trim() === "success"){
                            Swal.fire(
                                'Updated!',
                                'Option status has been set to Inactive.',
                                'success'
                            );
                            fetchCategory();
                        } else {
                            Swal.fire(
                                'Error!',
                                'Failed to update option status.',
                                'error'
                            );
                        }
                    }
                });
            }
        });
    });

    // Apply filter on dropdown change
    $('#filter-dropdown').on('change', function() {
        applyFilter();
    });

    // Initial fetch of sellers on page load
    $(document).ready(function() {
        fetchSellers();
    });
    </script>
</body>
</html>
