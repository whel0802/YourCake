<?php
session_start();    
if (empty($_SESSION['userlogin'])) {
    header('Location: ../login.php');
    exit;
}
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}


$user = isset($_SESSION['userlogin']['username']) ? $_SESSION['userlogin']['username'] : '';

include("../db_connection.php");

if (isset($_SESSION['success'])) {
    echo "<script>alert('{$_SESSION['success']}');</script>";
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    echo "<script>alert('{$_SESSION['error']}');</script>";
    unset($_SESSION['error']);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="/YourCake/pic/logo.png" />

    <!---  CSS -->
    <link rel="stylesheet" href="../css/SellerNavbar.css">
    <link rel="stylesheet" href="../css/SellerProduct.css">

    <!--- Boxicons CSS -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 

    <title>YourCake</title>
</head>
<body>
    <nav class="sidebar close">
        <header>
            <i class='bx bx-menu toggle icon'></i>
            <div class="image-text">
                <span class="image">
                    <img src="/YourCake/pic/logo.png" alt="logo">
                </span>

                <div class="text header-text">
                    <span class="name"> YourCake
                    <span class="user">@<?php echo $user; ?></p>
                </div>
            </div>
            
        </header>

        <div class="menu-bar">
            <div class="menu">
                <ul class="menu-links">
                    
                    <li class="nav-link">
                        <a href="Admin_SellerList.php">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Home</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="Admin_SellerList.php">
                            <i class='bx bx-customize icon'></i>
                            <span class="text nav-text">Customization</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="Admin_Users.php">
                            <i class='bx bx-list-ul icon' ></i>
                            <span class="text nav-text">Product List</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-calendar icon' ></i>
                            <span class="text nav-text">Schedule</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-bar-chart-square icon' ></i>
                            <span class="text nav-text">Sales</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-cabinet icon' ></i>
                            <span class="text nav-text">Inventory</span>
                        </a>
                    </li>
                    
                </ul>
            </div>

            <div class="bottom-content">
                <li class="nav-link">
                    <a href="../logout.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
            </div>
        </div>
    </nav>


    <section class="Content">

        <div class="container">
            <div class="ProductTable">
                <div class="prodHeader">
                    <i class='bx bx-list-ul icon' ></i>
                    <span class="prodSpan">User List</span>
                </div>
                <div class="prodControls">
                    <p>Filtered by:</p>
                    <select name="filter" id="filter-dropdown">
                        <option value="all">All</option>
                        <option value="Customer">Customer</option>
                        <option value="Seller">Seller</option>
                    </select>
                </div>

                <table class="ProdTable" id="ProdTable">
                    <thead>
                        <tr class="tableHeader">
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Phone Number</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>User Type</th>
                        </tr>
                    </thead>
<tbody>
                    </tbody>
                </table>
                
            </div>
            
            </div>

    </section>

    <script src="../navbar.js"></script>
    <script src="/YourCake/js/product.js"></script>

    <script>
        // Filter table rows based on user type
        const filterDropdown = document.getElementById('filter-dropdown');
        filterDropdown.addEventListener('change', function() {
            const filterValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('#ProdTable tbody tr');
            rows.forEach(row => {
                const userTypeCell = row.cells[5]; // User Type is the 6th column (0-based index 5)
                if (!userTypeCell) return;
                const userTypeText = userTypeCell.textContent.toLowerCase();
                if (filterValue === 'all' || userTypeText === filterValue) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        function applyFilter() {
            const filterValue = $('#filter-dropdown').val().toLowerCase();
            $('#ProdTable tbody tr').each(function() {
                const userTypeText = $(this).find('td').eq(5).text().toLowerCase();
                if (filterValue === 'all' || userTypeText === filterValue) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }

        function fetchUsers() {
            $.ajax({
                url: '../functions/get_users.php',
                type: 'GET',
                success: function(data) {
                    $('#ProdTable tbody').html(data);
                    applyFilter();
                },
                error: function() {
                    console.error('Failed to fetch users');
                }
            });
        }

        $(document).ready(function() {
            fetchUsers();
        });
    </script>
</body>
</html>
