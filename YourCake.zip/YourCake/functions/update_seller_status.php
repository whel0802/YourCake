<?php
session_start();

// Check if user is logged in and is admin
if (empty($_SESSION['userlogin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo "Unauthorized access";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['SellerUsername']) && isset($_POST['Status'])) {
        $sellerUsername = $_POST['SellerUsername'];
        $status = $_POST['Status'];

        // Validate status value
        $allowedStatuses = ['Approved', 'Rejected', 'Pending'];
        if (!in_array($status, $allowedStatuses)) {
            echo "Invalid status value";
            exit;
        }

include("../db_connection.php");

        // Prepare and bind to prevent SQL injection
        $stmt = $conn->prepare("UPDATE Seller SET Status = ? WHERE Seller_Username = ?");
        if ($stmt === false) {
            echo "Failed to prepare statement";
            exit;
        }
        $stmt->bind_param("ss", $status, $sellerUsername);

        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "Failed to update status";
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "Missing parameters";
    }
} else {
    echo "Invalid request method";
}
?>
