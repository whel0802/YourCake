<?php
include("../db_connection.php");

header('Content-Type: text/html; charset=utf-8');

$sql = "SELECT DISTINCT Purpose FROM options WHERE Status = 'Active' ORDER BY Purpose ASC";
$result = $conn->query($sql);

echo '<option value="all">All</option>';

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $purpose = htmlspecialchars($row['Purpose']);
        echo "<option value=\"{$purpose}\">{$purpose}</option>";
    }
}
?>
