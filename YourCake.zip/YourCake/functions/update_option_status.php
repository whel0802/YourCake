<?php
session_start();

if (empty($_SESSION['userlogin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo "Unauthorized access";
    exit;
}

include("../db_connection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $optionID = isset($_POST['OptionID']) ? $_POST['OptionID'] : '';

    if (empty($optionID)) {
        echo "error";
        exit;
    }

    $stmt = $conn->prepare("UPDATE options SET Status = 'Inactive' WHERE OptionID = ?");
    $stmt->bind_param("i", $optionID);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request";
}
?>
