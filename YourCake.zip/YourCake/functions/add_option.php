<?php
session_start();

if (empty($_SESSION['userlogin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo "Unauthorized access";
    exit;
}

include("../db_connection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $purpose = isset($_POST['Purpose']) ? trim($_POST['Purpose']) : '';
    $options = isset($_POST['Options']) ? trim($_POST['Options']) : '';

    if ($purpose === '' || $purpose === 'all' || $options === '') {
        http_response_code(400);
        echo "Invalid input";
        exit;
    }


    $normalizedPurpose = ucfirst(strtolower($purpose));
    $normalizedOptions = ucfirst(strtolower($options));

    if ($normalizedPurpose === 'New') {
        
        $checkPurposeStmt = $conn->prepare("SELECT COUNT(*) FROM options WHERE LOWER(Purpose) = LOWER(?) AND Status = 'Active'");
        $checkPurposeStmt->bind_param("s", $normalizedOptions);
        $checkPurposeStmt->execute();
        $checkPurposeStmt->bind_result($countPurpose);
        $checkPurposeStmt->fetch();
        $checkPurposeStmt->close();

        if ($countPurpose > 0) {
            http_response_code(409); 
            echo "Duplicate purpose";
            $conn->close();
            exit;
        }

        
        $stmt = $conn->prepare("INSERT INTO options (Purpose, Options, Status) VALUES (?, '', 'Active')");
        $stmt->bind_param("s", $normalizedOptions);

        if ($stmt->execute()) {
            echo "success";
        } else {
            http_response_code(500);
            echo "Database error";
        }

        $stmt->close();
        $conn->close();
        exit;
    }

    
    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM options WHERE LOWER(Purpose) = LOWER(?) AND LOWER(Options) = LOWER(?) AND Status = 'Active'");
    $checkStmt->bind_param("ss", $normalizedPurpose, $normalizedOptions);
    $checkStmt->execute();
    $checkStmt->bind_result($count);
    $checkStmt->fetch();
    $checkStmt->close();

    if ($count > 0) {
        http_response_code(409); 
        echo "Duplicate entry";
        $conn->close();
        exit;
    }

    // Insert 
    $stmt = $conn->prepare("INSERT INTO options (Purpose, Options, Status) VALUES (?, ?, 'Active')");
    $stmt->bind_param("ss", $normalizedPurpose, $normalizedOptions);

    if ($stmt->execute()) {
        echo "success";
    } else {
        http_response_code(500);
        echo "Database error";
    }

    $stmt->close();
    $conn->close();
} else {
    http_response_code(405);
    echo "Method not allowed";
}
?>
