<?php
session_start();

if (empty($_SESSION['userlogin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo "Unauthorized access";
    exit;
}

include("../db_connection.php");
$sql = "SELECT * FROM options WHERE Status = 'Active'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        echo "<tr 
            data-OptionID='{$row['OptionID']}'
            data-Purpose='{$row['Purpose']}'
            data-Options='{$row['Options']}'>"; 
        echo "<td>{$row['OptionID']}</td>";
        echo "<td>{$row['Purpose']}</td>";
        echo "<td>{$row['Options']}</td>";
        echo "<td><button class='inactive-button' data-id='{$row['OptionID']}'><i class='bx bx-trash'></i></button></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No records found</td></tr>";
}

$conn->close();
?>
