<?php
session_start();

if (empty($_SESSION['userlogin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo "Unauthorized access";
    exit;
}

include("../db_connection.php");

$sql = "SELECT Seller_Username as Username, FirstName, MiddleName, LastName, NameExt, PhoneNumber, Email, Street, HouseNo, Barangay, 'Seller' as UserType FROM Seller
        UNION ALL
        SELECT Cust_Username as Username, FirstName, MiddleName, LastName, NameExt, PhoneNumber, Email, Street, '' as HouseNo, Barangay, 'Customer' as UserType FROM Customer";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullName = trim($row['FirstName'] . ' ' . $row['MiddleName'] . ' ' . $row['LastName'] . ' ' . $row['NameExt']);
        $address = trim($row['Street'] . ' ' . $row['HouseNo'] . ', ' . $row['Barangay']);
        echo "<tr 
            data-Username='{$row['Username']}'
            data-FirstName='{$row['FirstName']}'
            data-MiddleName='{$row['MiddleName']}'
            data-LastName='{$row['LastName']}'
            data-NameExt='{$row['NameExt']}'
            data-PhoneNumber='{$row['PhoneNumber']}'
            data-Email='{$row['Email']}'
            data-Street='{$row['Street']}'
            data-HouseNo='{$row['HouseNo']}'
            data-Barangay='{$row['Barangay']}'
            data-UserType='{$row['UserType']}'
        >";
        echo "<td>{$row['Username']}</td>";
        echo "<td>{$fullName}</td>";
        echo "<td>{$row['PhoneNumber']}</td>";
        echo "<td>{$row['Email']}</td>";
        echo "<td>{$address}</td>";
        echo "<td>{$row['UserType']}</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No records found</td></tr>";
}

$conn->close();
?>
