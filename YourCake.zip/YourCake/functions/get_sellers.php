<?php
session_start();

if (empty($_SESSION['userlogin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo "Unauthorized access";
    exit;
}

include("../db_connection.php");

$sql = "SELECT * FROM Seller";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr 
            data-Username='{$row['Seller_Username']}'
            data-FirstName='{$row['FirstName']}'
            data-MiddleName='{$row['MiddleName']}'
            data-LastName='{$row['LastName']}'
            data-NameExt='{$row['NameExt']}'
            data-PhoneNumber='{$row['PhoneNumber']}'
            data-Email='{$row['Email']}'
            data-Street='{$row['Street']}'
            data-HouseNo='{$row['HouseNo']}'
            data-Barangay='{$row['Barangay']}'
            data-ShopName='{$row['ShopName']}'
            data-ShopType='{$row['ShopType']}'
            data-Landmark='{$row['Landmark']}'
            data-ValidId='{$row['ValidId']}'
            data-SellerPicture='{$row['SellerPicture']}'
            data-SellerLogo='{$row['SellerLogo']}'
            data-Requirement='{$row['Requirement']}'
            data-Status='{$row['Status']}'
            data-Customization='{$row['Customization']}'
        >";
        echo "<td>{$row['Seller_Username']}</td>";
        echo "<td>{$row['FirstName']} {$row['MiddleName']} {$row['LastName']} {$row['NameExt']}</td>";
        echo "<td>{$row['PhoneNumber']}</td>";
        echo "<td>{$row['Email']}</td>";
        echo "<td>{$row['Street']} {$row['HouseNo']}, {$row['Barangay']}</td>";
        echo "<td>{$row['ShopName']}</td>";
        echo "<td>{$row['ShopType']}</td>";
        echo "<td>{$row['Landmark']}</td>";
        echo "<td><img src='../uploads/{$row['ValidId']}' alt='Valid ID' width='60' height='60'></td>";
        echo "<td><img src='../uploads/{$row['SellerPicture']}' alt='Seller Picture' width='60' height='60'></td>";
        echo "<td><img src='../uploads/{$row['SellerLogo']}' alt='Seller Logo' width='60' height='60'></td>";
        echo "<td><img src='../uploads/{$row['Requirement']}' alt='Seller Logo' width='60' height='60'></td>";
        echo "<td>{$row['Status']}</td>";
        echo "<td>{$row['Customization']}</td>";
        echo "<td><button class='delete-button' data-id='{$row['Seller_Username']}'><i class='bx bx-trash'></i></button></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='15'>No records found</td></tr>";
}

$conn->close();
?>
